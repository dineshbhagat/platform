package com.dkb.java13;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Java13ApplicationTests {

	@Test
	void contextLoads() {
	}

}
